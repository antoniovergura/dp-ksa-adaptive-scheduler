# Riepilogo economico individuale — DEMO-T040

DOCUMENTO FITTIZIO PER TEST. Nessun dato appartiene a persone o aziende reali.

Azienda: Aurora Demo Srl (società inventata).
Periodo di riferimento: anno 2026. Valori espressi in euro.
Identificativo del dipendente fittizio: DEMO-T040.
Reparto: Tecnologia. Livello: T2. Mansione: Sviluppo software.
Sede assegnata: Torino. Assegnazione interna: Progetto Nube.
Anno di assunzione fittizio: 2020. Contratto a tempo pieno.

La retribuzione annua lorda base di questo dipendente è 42000 euro.
La base è corrisposta in 14 mensilità; non comprende il premio variabile.
Il bonus individuale previsto per il 2026 è 0 euro lordi.
Il totale annuo lordo previsto, base più bonus, è 42000 euro.

Il bonus dipende dagli obiettivi individuali e non modifica la base. Il documento non contiene stipendio netto, imposte, IBAN, codice fiscale o informazioni su altri dipendenti.
